import mongoose from "mongoose";

const subscriptionSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Subscription name is required'],
      trim: true,
      minlength: 2,
      maxlength: 100,
    },

    price: {
      type: Number,
      required: [true, 'Subscription price is required'],
      min: [0, 'Price must be greater than 0'],
    },

    // 1. Diperbaiki: Enum mata uang yang benar
    currency: {
      type: String,
      enum: ['USD', 'EUR', 'GBP', 'IDR'],
      default: 'IDR',
    },

    // 2. Ditambahkan: Field frequency yang sebelumnya hilang
    frequency: {
      type: String,
      enum: ['daily', 'weekly', 'monthly', 'yearly'],
      required: [true, 'Subscription frequency is required'],
    },

    // 3. Diperbaiki: Typo 'entertainment' (ditambah huruf n)
    category: {
      type: String,
      enum: ['sports', 'news', 'entertainment', 'lifestyle', 'technology', 'finance', 'politics', 'other'],
      required: true,
    },

    paymentMethod: {
      type: String,
      required: true,
      trim: true,
    },

    status: {
      type: String,
      enum: ['active', 'canceled', 'expired'],
      default: 'active',
    },

    startDate: {
      type: Date,
      required: true,
      validate: {
        validator: (value) => value <= new Date(),
        message: 'Start date must be in the past or today',
      },
    },

    renewalDate: {
      type: Date,
      validate: {
        validator: function (value) {
          return value > this.startDate;
        },
        message: 'Renewal date must be after the start date',
      },
    },

    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
  },
  { timestamps: true }
);

// 4. Diubah ke pre('validate') agar renewalDate dihitung SEBELUM schema divalidasi
subscriptionSchema.pre('validate', function (next) {
  if (!this.renewalDate && this.startDate) {
    const renewalPeriods = {
      daily: 1,
      weekly: 7,
      monthly: 30,
      yearly: 365,
    };

    this.renewalDate = new Date(this.startDate);
    this.renewalDate.setDate(this.renewalDate.getDate() + (renewalPeriods[this.frequency] || 30));
  }

  if (this.renewalDate && this.renewalDate < new Date()) {
    this.status = 'expired';
  }

  next();
});

const Subscription = mongoose.model('Subscription', subscriptionSchema);

export default Subscription;